interface OnClickListener {
    void onClick();
}